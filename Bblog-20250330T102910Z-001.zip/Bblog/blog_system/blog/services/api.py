import requests

def get_country_data(country_code):
    try:
        response = requests.get(f"https://restcountries.com/v3.1/alpha/{country_code}")
        return response.json()[0]  # Return first match
    except Exception as e:
        print(f"API Error: {e}")
        return None