from django.views.generic import ListView, DetailView
from .models import Blog
from .services.api import get_country_data

class BlogListView(ListView):
    model = Blog
    template_name = "blog/list.html"
    context_object_name = "blogs"

class BlogDetailView(DetailView):
    model = Blog
    template_name = "blog/detail.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        country_data = get_country_data(self.object.country_code)
        context["country_data"] = country_data
        return context